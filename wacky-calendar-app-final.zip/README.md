# Wacky Calendar

Make your time interesting with randomized schedules! 🎲

## Overview

Wacky Calendar is a web application that transforms mundane scheduling into an engaging experience by randomizing the order of daily tasks. Simply input your available time windows and tasks, then receive an AI-generated schedule that shuffles tasks in unexpected ways while respecting your time constraints.

## Features

- ✨ **Smart Task Randomization** - Shuffle your daily tasks for a fresh perspective
- 🎯 **Multiple Time Windows** - Set one or multiple time blocks throughout your day
- 🏃 **Outdoor Task Grouping** - Automatically groups consecutive outdoor activities
- 📅 **Google Calendar Integration** - One-click export to Google Calendar with OAuth
- 💾 **Download .ics Files** - Compatible with Apple Calendar, Outlook, and more
- 🔒 **Secure & Private** - Rate limiting, token expiry tracking, input sanitization
- 📱 **Responsive Design** - Works beautifully on desktop and mobile

## Quick Start

1. **Clone the repository**
   ```bash
   git clone https://github.com/YOUR_USERNAME/wacky-calendar-app.git
   cd wacky-calendar-app
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up Google Calendar (Optional)**
   - Create a project in [Google Cloud Console](https://console.cloud.google.com)
   - Enable the Google Calendar API
   - Create OAuth 2.0 credentials
   - Add to `.env.local`:
     ```
     NEXT_PUBLIC_GOOGLE_CLIENT_ID=your_client_id_here
     ```

4. **Run the development server**
   ```bash
   npm run dev
   ```

5. **Open [http://localhost:3000](http://localhost:3000)** in your browser

## Tech Stack

- **Framework**: Next.js 16 (App Router)
- **Language**: TypeScript
- **Styling**: Tailwind CSS 4
- **UI Components**: Radix UI
- **OAuth**: @react-oauth/google
- **File Export**: file-saver

## Usage

1. **Set Your Time Windows**
   - Choose between single or multiple time windows
   - Use presets (Morning, Afternoon, Evening) or custom times

2. **Add Your Tasks**
   - Enter task names and durations
   - Tasks are auto-detected as indoor/outdoor
   - Durations are intelligently estimated

3. **Generate Schedule**
   - Click "Make My Time Interesting"
   - Tasks are shuffled randomly
   - Outdoor tasks are grouped together

4. **Export**
   - Download as .ics file for any calendar app
   - OR sign in and export directly to Google Calendar

## Environment Variables

Create a `.env.local` file in the root directory:

```env
# Optional - for Google Calendar integration
NEXT_PUBLIC_GOOGLE_CLIENT_ID=your_google_client_id
```

## Deployment

### Vercel (Recommended)

1. Push your code to GitHub
2. Import your repository in [Vercel](https://vercel.com)
3. Add environment variables in project settings
4. Deploy!

### Manual Deployment

```bash
npm run build
npm start
```

## Security Features

- **Rate Limiting**: 3-second cooldown between Google Calendar exports
- **Token Expiry Tracking**: Automatic session expiration handling
- **Input Sanitization**: XSS prevention for task names and descriptions
- **OAuth 2.0**: Secure Google Calendar authentication

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

MIT License - feel free to use this project for personal or commercial purposes.

## Acknowledgments

Built with ❤️ using Next.js and Tailwind CSS

---

**Ready to make your schedule more interesting?** [Try it now!](http://localhost:3000)
