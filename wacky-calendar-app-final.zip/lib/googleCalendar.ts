// Helper functions for Google Calendar API integration

/**
 * Sanitize text input to prevent XSS and limit length
 * @param text Input text to sanitize
 * @param maxLength Maximum allowed length (default: 500)
 * @returns Sanitized text
 */
function sanitizeText(text: string, maxLength: number = 500): string {
    return text
        .replace(/[<>]/g, '') // Remove HTML brackets
        .replace(/\\/g, '') // Remove backslashes
        .trim()
        .substring(0, maxLength)
}

export interface ScheduledTask {
    id: string
    name: string
    startTime: Date
    endTime: Date
}

/**
 * Export schedule to Google Calendar using the Calendar API
 * @param schedule Array of scheduled tasks
 * @param accessToken OAuth access token from Google
 * @returns Promise that resolves when all events are created
 */
export async function exportToGoogleCalendar(
    schedule: ScheduledTask[],
    accessToken: string
): Promise<void> {
    const CALENDAR_API_URL = 'https://www.googleapis.com/calendar/v3/calendars/primary/events'

    // Create all events in parallel
    const promises = schedule.map(async (task) => {
        const event = {
            summary: sanitizeText(task.name, 200), // Sanitize and limit to 200 chars
            start: {
                dateTime: task.startTime.toISOString(),
                timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
            },
            end: {
                dateTime: task.endTime.toISOString(),
                timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
            },
            description: `Created by Wacky Calendar`,
        }

        const response = await fetch(CALENDAR_API_URL, {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${accessToken}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(event),
        })

        if (!response.ok) {
            const error = await response.json()
            throw new Error(`Failed to create event: ${error.error?.message || 'Unknown error'}`)
        }

        return response.json()
    })

    await Promise.all(promises)
}
