
import { NextRequest, NextResponse } from 'next/server'

export async function POST(req: NextRequest) {
    try {
        // Parse JSON body from fetch request
        const body = await req.json()
        const { schedule } = body
        if (!schedule || !Array.isArray(schedule)) {
            return new NextResponse('Invalid schedule data', { status: 400 })
        }

        let icsContent = 'BEGIN:VCALENDAR\nVERSION:2.0\nPRODID:-//Wacky Calendar//EN\nCALSCALE:GREGORIAN\n'

        schedule.forEach((task: any) => {
            // Format dates in local time (not UTC) for better calendar compatibility
            const formatICSDate = (dateStr: string) => {
                const date = new Date(dateStr)
                const year = date.getFullYear()
                const month = String(date.getMonth() + 1).padStart(2, '0')
                const day = String(date.getDate()).padStart(2, '0')
                const hours = String(date.getHours()).padStart(2, '0')
                const minutes = String(date.getMinutes()).padStart(2, '0')
                const seconds = '00'
                return `${year}${month}${day}T${hours}${minutes}${seconds}`
            }

            const startStr = formatICSDate(task.startTime)
            const endStr = formatICSDate(task.endTime)

            // Sanitize task name - escape special characters for ICS format
            const sanitizedName = task.name
                .replace(/\\/g, '\\\\')
                .replace(/;/g, '\\;')
                .replace(/,/g, '\\,')
                .replace(/\n/g, '\\n')

            icsContent += 'BEGIN:VEVENT\n'
            icsContent += `DTSTART:${startStr}\n`
            icsContent += `DTEND:${endStr}\n`
            icsContent += `SUMMARY:${sanitizedName}\n`

            if (task.description) {
                const sanitizedDesc = task.description
                    .replace(/\\/g, '\\\\')
                    .replace(/;/g, '\\;')
                    .replace(/,/g, '\\,')
                    .replace(/\n/g, '\\n')
                icsContent += `DESCRIPTION:${sanitizedDesc}\n`
            }

            icsContent += `UID:${task.id}@wackycalendar.com\n`
            icsContent += 'END:VEVENT\n'
        })

        icsContent += 'END:VCALENDAR'

        // Generate filename with current date
        const now = new Date()
        const year = now.getFullYear()
        const month = String(now.getMonth() + 1).padStart(2, '0')
        const day = String(now.getDate()).padStart(2, '0')
        const filename = `wacky-calendar-${year}-${month}-${day}.ics`

        return new NextResponse(icsContent, {
            headers: {
                'Content-Type': 'application/octet-stream',
                'Content-Disposition': `attachment; filename="${filename}"`,
            },
        })
    } catch (error) {
        console.error('ICS Export Error:', error)
        return new NextResponse('Internal Server Error', { status: 500 })
    }
}
