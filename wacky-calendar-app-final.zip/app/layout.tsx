import type { Metadata } from "next"
import "./globals.css"
import { GoogleOAuthProvider } from '@react-oauth/google'

export const metadata: Metadata = {
  title: "Wacky Calendar",
  description: "Make your time interesting with randomized schedules",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  const clientId = process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID

  if (!clientId) {
    console.error('Missing NEXT_PUBLIC_GOOGLE_CLIENT_ID environment variable')
  }

  return (
    <html lang="en" suppressHydrationWarning>
      <body className="antialiased">
        {clientId ? (
          <GoogleOAuthProvider clientId={clientId}>
            {children}
          </GoogleOAuthProvider>
        ) : (
          children
        )}
      </body>
    </html>
  )
}
