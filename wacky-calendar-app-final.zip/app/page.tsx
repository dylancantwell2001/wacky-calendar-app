'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Calendar, Plus, Trash2, Download, Copy, RotateCcw, Clock } from 'lucide-react'
import { saveAs } from 'file-saver'
import { useGoogleLogin } from '@react-oauth/google'
import { exportToGoogleCalendar } from '@/lib/googleCalendar'

interface Task {
  id: string
  name: string
  duration: number // in minutes
  isOutside: boolean
}

interface ScheduledTask extends Task {
  startTime: Date
  endTime: Date
}

// Analyze task name to estimate duration
const estimateDuration = (taskName: string): number => {
  const lowerTask = taskName.toLowerCase()

  // Quick tasks (15 min)
  if (
    lowerTask.includes('call') ||
    lowerTask.includes('email') ||
    lowerTask.includes('text') ||
    lowerTask.includes('message') ||
    lowerTask.includes('check')
  ) {
    return 15
  }

  // Medium tasks (30 min)
  if (
    lowerTask.includes('review') ||
    lowerTask.includes('read') ||
    lowerTask.includes('meeting') ||
    lowerTask.includes('evaluate')
  ) {
    return 30
  }

  // Longer tasks (45-60 min)
  if (
    lowerTask.includes('workout') ||
    lowerTask.includes('gym') ||
    lowerTask.includes('exercise') ||
    lowerTask.includes('run') ||
    lowerTask.includes('study') ||
    lowerTask.includes('write') ||
    lowerTask.includes('cook') ||
    lowerTask.includes('clean')
  ) {
    return 45
  }

  // Extended tasks (90+ min)
  if (
    lowerTask.includes('project') ||
    lowerTask.includes('research') ||
    lowerTask.includes('presentation')
  ) {
    return 90
  }

  // Default
  return 30
}

// Detect if task is outside
const isOutsideTask = (taskName: string): boolean => {
  const lowerTask = taskName.toLowerCase()

  return (
    lowerTask.includes('gym') ||
    lowerTask.includes('run') ||
    lowerTask.includes('jog') ||
    lowerTask.includes('walk') ||
    lowerTask.includes('hike') ||
    lowerTask.includes('bike') ||
    lowerTask.includes('outside') ||
    lowerTask.includes('outdoor') ||
    lowerTask.includes('park') ||
    lowerTask.includes('garden') ||
    lowerTask.includes('shop') ||
    lowerTask.includes('store') ||
    lowerTask.includes('errand') ||
    lowerTask.includes('groceries') ||
    lowerTask.includes('grocery')
  )
}

interface TimeWindow {
  id: string
  startHour: string
  startMinute: string
  startPeriod: string
  endHour: string
  endMinute: string
  endPeriod: string
}

export default function WackyCalendar() {
  const [timeWindowMode, setTimeWindowMode] = useState<'single' | 'multiple'>('single')
  const [timeWindows, setTimeWindows] = useState<TimeWindow[]>([])
  const [startHour, setStartHour] = useState('')
  const [startMinute, setStartMinute] = useState('')
  const [startPeriod, setStartPeriod] = useState('')
  const [endHour, setEndHour] = useState('')
  const [endMinute, setEndMinute] = useState('')
  const [endPeriod, setEndPeriod] = useState('')
  const [tasks, setTasks] = useState<Task[]>([])
  const [newTaskName, setNewTaskName] = useState('')
  const [newTaskDuration, setNewTaskDuration] = useState('')
  const [newTaskDescription, setNewTaskDescription] = useState('')
  const [schedule, setSchedule] = useState<ScheduledTask[] | null>(null)
  const [scheduleHistory, setScheduleHistory] = useState<ScheduledTask[][]>([])

  // Google Calendar state
  const [googleAccessToken, setGoogleAccessToken] = useState<string | null>(null)
  const [tokenExpiry, setTokenExpiry] = useState<number | null>(null)
  const [lastExportTime, setLastExportTime] = useState<number>(0)
  const [isExportingToGoogle, setIsExportingToGoogle] = useState(false)

  // Load from localStorage on mount
  useEffect(() => {
    const savedTasks = localStorage.getItem('wackyCalendar_tasks')
    const savedTimeWindows = localStorage.getItem('wackyCalendar_timeWindows')
    const savedMode = localStorage.getItem('wackyCalendar_mode')

    if (savedTasks) {
      try {
        setTasks(JSON.parse(savedTasks))
      } catch (e) {
        console.error('[v0] Failed to parse saved tasks')
      }
    }

    if (savedTimeWindows) {
      try {
        setTimeWindows(JSON.parse(savedTimeWindows))
      } catch (e) {
        console.error('[v0] Failed to parse saved time windows')
      }
    }

    if (savedMode) {
      setTimeWindowMode(savedMode as 'single' | 'multiple')
    }
  }, [])

  // Save to localStorage whenever tasks or timeWindows change
  useEffect(() => {
    localStorage.setItem('wackyCalendar_tasks', JSON.stringify(tasks))
  }, [tasks])

  useEffect(() => {
    localStorage.setItem('wackyCalendar_timeWindows', JSON.stringify(timeWindows))
  }, [timeWindows])

  useEffect(() => {
    localStorage.setItem('wackyCalendar_mode', timeWindowMode)
  }, [timeWindowMode])

  // Quick time presets
  const applyTimePreset = (preset: 'morning' | 'afternoon' | 'evening') => {
    switch (preset) {
      case 'morning':
        setStartHour('8')
        setStartMinute('00')
        setStartPeriod('AM')
        setEndHour('12')
        setEndMinute('00')
        setEndPeriod('PM')
        break
      case 'afternoon':
        setStartHour('1')
        setStartMinute('00')
        setStartPeriod('PM')
        setEndHour('5')
        setEndMinute('00')
        setEndPeriod('PM')
        break
      case 'evening':
        setStartHour('6')
        setStartMinute('00')
        setStartPeriod('PM')
        setEndHour('10')
        setEndMinute('00')
        setEndPeriod('PM')
        break
    }
  }

  // Clear all data
  const clearAllData = () => {
    if (confirm('Are you sure you want to clear all tasks and time windows? This cannot be undone.')) {
      setTasks([])
      setTimeWindows([])
      setSchedule(null)
      setScheduleHistory([])
      setStartHour('')
      setStartMinute('')
      setStartPeriod('')
      setEndHour('')
      setEndMinute('')
      setEndPeriod('')
      localStorage.removeItem('wackyCalendar_tasks')
      localStorage.removeItem('wackyCalendar_timeWindows')
    }
  }

  // Copy schedule to clipboard
  const copyScheduleToClipboard = () => {
    if (!schedule || schedule.length === 0) return

    let text = 'Wacky Calendar Schedule\n\n'
    schedule.forEach((task, index) => {
      text += `${index + 1}. ${task.name}\n`
      text += `   ${formatTime(task.startTime)} - ${formatTime(task.endTime)} (${task.duration} min)\n`
      if (task.description) {
        text += `   Note: ${task.description}\n`
      }
      text += '\n'
    })

    navigator.clipboard.writeText(text).then(() => {
      alert('Schedule copied to clipboard!')
    }).catch(() => {
      alert('Failed to copy to clipboard')
    })
  }

  // Smart handler for start hour selection
  const handleStartHourChange = (hour: string) => {
    setStartHour(hour)

    // Auto-assign minute to 00 if not set
    if (!startMinute) {
      setStartMinute('00')
    }

    // Auto-assign period based on current time if not set
    if (!startPeriod) {
      const currentHour = new Date().getHours()
      const selectedHour = parseInt(hour)

      // If current time is AM (0-11), default to AM unless hour is small (suggests afternoon)
      if (currentHour < 12) {
        setStartPeriod(selectedHour >= 8 ? 'AM' : 'PM')
      } else {
        // If current time is PM (12-23), default to PM
        setStartPeriod('PM')
      }
    }
  }

  // Smart handler for end hour selection
  const handleEndHourChange = (hour: string) => {
    setEndHour(hour)

    // Auto-assign minute to 00 if not set
    if (!endMinute) {
      setEndMinute('00')
    }

    // Auto-assign period based on start time
    if (startHour && startPeriod) {
      const selectedEndHour = parseInt(hour)
      const selectedStartHour = parseInt(startHour)

      // If end hour is less than or equal to start hour, assume next period
      if (selectedEndHour <= selectedStartHour) {
        setEndPeriod(startPeriod === 'AM' ? 'PM' : 'PM')
      } else {
        setEndPeriod(startPeriod)
      }
    }
  }

  const addTimeWindow = () => {
    if (startHour && startMinute && startPeriod && endHour && endMinute && endPeriod) {
      // Validate that end time is after start time
      let startHour24 = parseInt(startHour)
      if (startPeriod === 'PM' && startHour24 !== 12) {
        startHour24 += 12
      } else if (startPeriod === 'AM' && startHour24 === 12) {
        startHour24 = 0
      }

      let endHour24 = parseInt(endHour)
      if (endPeriod === 'PM' && endHour24 !== 12) {
        endHour24 += 12
      } else if (endPeriod === 'AM' && endHour24 === 12) {
        endHour24 = 0
      }

      const startDate = new Date()
      startDate.setHours(startHour24, parseInt(startMinute), 0, 0)

      const endDate = new Date()
      endDate.setHours(endHour24, parseInt(endMinute), 0, 0)

      // Check if end is after start
      if (endDate <= startDate) {
        alert('End time must be after start time')
        return
      }

      // Check for overlapping windows
      const hasOverlap = timeWindows.some((window) => {
        let windowStartHour24 = parseInt(window.startHour)
        if (window.startPeriod === 'PM' && windowStartHour24 !== 12) {
          windowStartHour24 += 12
        } else if (window.startPeriod === 'AM' && windowStartHour24 === 12) {
          windowStartHour24 = 0
        }

        let windowEndHour24 = parseInt(window.endHour)
        if (window.endPeriod === 'PM' && windowEndHour24 !== 12) {
          windowEndHour24 += 12
        } else if (window.endPeriod === 'AM' && windowEndHour24 === 12) {
          windowEndHour24 = 0
        }

        const windowStart = new Date()
        windowStart.setHours(windowStartHour24, parseInt(window.startMinute), 0, 0)

        const windowEnd = new Date()
        windowEnd.setHours(windowEndHour24, parseInt(window.endMinute), 0, 0)

        // Check if windows overlap
        return (startDate < windowEnd && endDate > windowStart)
      })

      if (hasOverlap) {
        alert('Time windows cannot overlap')
        return
      }

      const newWindow = {
        id: `${Date.now()}-${Math.random()}`,
        startHour,
        startMinute,
        startPeriod,
        endHour,
        endMinute,
        endPeriod,
      }

      const updatedWindows = [...timeWindows, newWindow]

      // Sort windows chronologically
      updatedWindows.sort((a, b) => {
        let aHour24 = parseInt(a.startHour)
        if (a.startPeriod === 'PM' && aHour24 !== 12) aHour24 += 12
        else if (a.startPeriod === 'AM' && aHour24 === 12) aHour24 = 0

        let bHour24 = parseInt(b.startHour)
        if (b.startPeriod === 'PM' && bHour24 !== 12) bHour24 += 12
        else if (b.startPeriod === 'AM' && bHour24 === 12) bHour24 = 0

        const aTime = aHour24 * 60 + parseInt(a.startMinute)
        const bTime = bHour24 * 60 + parseInt(b.startMinute)

        return aTime - bTime
      })

      setTimeWindows(updatedWindows)
      setStartHour('')
      setStartMinute('')
      setStartPeriod('')
      setEndHour('')
      setEndMinute('')
      setEndPeriod('')
    }
  }

  const removeTimeWindow = (id: string) => {
    setTimeWindows(timeWindows.filter((tw) => tw.id !== id))
    setSchedule(null) // Clear schedule when time windows change
  }

  const handleModeChange = (mode: 'single' | 'multiple') => {
    setTimeWindowMode(mode)
    setSchedule(null) // Clear schedule when switching modes
  }

  const addTask = () => {
    const trimmedName = newTaskName.trim()

    // Validate task name is not empty and meaningful
    if (!trimmedName || trimmedName.length < 2) {
      return
    }

    const estimatedDuration = estimateDuration(trimmedName)
    const isOutside = isOutsideTask(trimmedName)
    const duration = parseInt(newTaskDuration) || estimatedDuration

    // Validate duration is positive
    if (duration <= 0 || duration > 1440) { // Max 24 hours
      alert('Task duration must be between 1 minute and 24 hours')
      return
    }

    setTasks([
      ...tasks,
      {
        id: `${Date.now()}-${Math.random()}`,
        name: trimmedName,
        duration: duration,
        isOutside: isOutside,
        description: newTaskDescription.trim() || undefined,
      },
    ])
    setNewTaskName('')
    setNewTaskDuration('')
    setNewTaskDescription('')
  }

  const removeTask = (id: string) => {
    setTasks(tasks.filter((task) => task.id !== id))
    setSchedule(null) // Clear schedule when tasks change
  }

  // Calculate available time and check if tasks fit
  const getTimeValidation = () => {
    if (tasks.length === 0) {
      return { isValid: true, availableMinutes: 0, totalTaskMinutes: 0 }
    }

    let availableMinutes = 0

    if (timeWindowMode === 'single') {
      if (!startHour || !startMinute || !startPeriod || !endHour || !endMinute || !endPeriod) {
        return { isValid: true, availableMinutes: 0, totalTaskMinutes: 0 }
      }

      // Convert 12-hour to 24-hour format
      let startHour24 = parseInt(startHour)
      if (startPeriod === 'PM' && startHour24 !== 12) {
        startHour24 += 12
      } else if (startPeriod === 'AM' && startHour24 === 12) {
        startHour24 = 0
      }

      let endHour24 = parseInt(endHour)
      if (endPeriod === 'PM' && endHour24 !== 12) {
        endHour24 += 12
      } else if (endPeriod === 'AM' && endHour24 === 12) {
        endHour24 = 0
      }

      const start = new Date()
      start.setHours(startHour24, parseInt(startMinute), 0, 0)

      const end = new Date()
      end.setHours(endHour24, parseInt(endMinute), 0, 0)

      availableMinutes = Math.floor((end.getTime() - start.getTime()) / (1000 * 60))

      // Prevent negative time windows
      if (availableMinutes <= 0) {
        return { isValid: false, availableMinutes: 0, totalTaskMinutes: tasks.reduce((sum, task) => sum + task.duration, 0) }
      }
    } else {
      // Multiple windows mode
      if (timeWindows.length === 0) {
        return { isValid: true, availableMinutes: 0, totalTaskMinutes: 0 }
      }

      timeWindows.forEach((window) => {
        let startHour24 = parseInt(window.startHour)
        if (window.startPeriod === 'PM' && startHour24 !== 12) {
          startHour24 += 12
        } else if (window.startPeriod === 'AM' && startHour24 === 12) {
          startHour24 = 0
        }

        let endHour24 = parseInt(window.endHour)
        if (window.endPeriod === 'PM' && endHour24 !== 12) {
          endHour24 += 12
        } else if (window.endPeriod === 'AM' && endHour24 === 12) {
          endHour24 = 0
        }

        const start = new Date()
        start.setHours(startHour24, parseInt(window.startMinute), 0, 0)

        const end = new Date()
        end.setHours(endHour24, parseInt(window.endMinute), 0, 0)

        availableMinutes += Math.floor((end.getTime() - start.getTime()) / (1000 * 60))
      })
    }

    const totalTaskMinutes = tasks.reduce((sum, task) => sum + task.duration, 0)

    return {
      isValid: totalTaskMinutes <= availableMinutes,
      availableMinutes,
      totalTaskMinutes
    }
  }

  const timeValidation = getTimeValidation()

  const generateSchedule = () => {
    if (tasks.length === 0) return

    // Get all time windows
    let windows: Array<{ start: Date; end: Date }> = []

    if (timeWindowMode === 'single') {
      if (!startHour || !startMinute || !startPeriod || !endHour || !endMinute || !endPeriod) return

      // Convert 12-hour to 24-hour format
      let startHour24 = parseInt(startHour)
      if (startPeriod === 'PM' && startHour24 !== 12) {
        startHour24 += 12
      } else if (startPeriod === 'AM' && startHour24 === 12) {
        startHour24 = 0
      }

      let endHour24 = parseInt(endHour)
      if (endPeriod === 'PM' && endHour24 !== 12) {
        endHour24 += 12
      } else if (endPeriod === 'AM' && endHour24 === 12) {
        endHour24 = 0
      }

      const start = new Date()
      start.setHours(startHour24, parseInt(startMinute), 0, 0)

      const end = new Date()
      end.setHours(endHour24, parseInt(endMinute), 0, 0)

      windows = [{ start, end }]
    } else {
      // Multiple windows mode
      if (timeWindows.length === 0) return

      windows = timeWindows.map((window) => {
        let startHour24 = parseInt(window.startHour)
        if (window.startPeriod === 'PM' && startHour24 !== 12) {
          startHour24 += 12
        } else if (window.startPeriod === 'AM' && startHour24 === 12) {
          startHour24 = 0
        }

        let endHour24 = parseInt(window.endHour)
        if (window.endPeriod === 'PM' && endHour24 !== 12) {
          endHour24 += 12
        } else if (window.endPeriod === 'AM' && endHour24 === 12) {
          endHour24 = 0
        }

        const start = new Date()
        start.setHours(startHour24, parseInt(window.startMinute), 0, 0)

        const end = new Date()
        end.setHours(endHour24, parseInt(window.endMinute), 0, 0)

        return { start, end }
      })

      // Sort windows by start time
      windows.sort((a, b) => a.start.getTime() - b.start.getTime())
    }

    // Separate outside and inside tasks
    const outsideTasks = tasks.filter((task) => task.isOutside)
    const insideTasks = tasks.filter((task) => !task.isOutside)

    // Randomize each group
    const shuffledOutside = [...outsideTasks].sort(() => Math.random() - 0.5)
    const shuffledInside = [...insideTasks].sort(() => Math.random() - 0.5)

    // Combine: try to keep outside tasks together
    let orderedTasks: Task[] = []
    if (shuffledOutside.length > 0 && shuffledInside.length > 0) {
      // Randomly decide where to place outside tasks (beginning, middle, or end)
      const position = Math.floor(Math.random() * 3)
      if (position === 0) {
        orderedTasks = [...shuffledOutside, ...shuffledInside]
      } else if (position === 1) {
        const midPoint = Math.floor(shuffledInside.length / 2)
        orderedTasks = [
          ...shuffledInside.slice(0, midPoint),
          ...shuffledOutside,
          ...shuffledInside.slice(midPoint),
        ]
      } else {
        orderedTasks = [...shuffledInside, ...shuffledOutside]
      }
    } else {
      orderedTasks = [...shuffledOutside, ...shuffledInside]
    }

    // Create schedule across all windows
    const scheduledTasks: ScheduledTask[] = []
    let windowIndex = 0
    let currentTime = new Date(windows[0].start)

    for (const task of orderedTasks) {
      const taskEnd = new Date(currentTime.getTime() + task.duration * 60000)

      // Check if task fits in current window
      if (taskEnd > windows[windowIndex].end) {
        // Move to next window
        windowIndex++
        if (windowIndex >= windows.length) break // No more windows available

        currentTime = new Date(windows[windowIndex].start)
        const newTaskEnd = new Date(currentTime.getTime() + task.duration * 60000)

        // Check if task fits in new window
        if (newTaskEnd > windows[windowIndex].end) continue // Skip this task
      }

      const taskStart = new Date(currentTime)
      const finalTaskEnd = new Date(currentTime.getTime() + task.duration * 60000)

      scheduledTasks.push({
        ...task,
        startTime: taskStart,
        endTime: finalTaskEnd,
      })

      currentTime = finalTaskEnd
    }

    // Save to history (keep last 3)
    if (schedule) {
      setScheduleHistory([schedule, ...scheduleHistory.slice(0, 2)])
    }

    setSchedule(scheduledTasks)
  }

  // Regenerate schedule (randomize again)
  const regenerateSchedule = () => {
    generateSchedule()
  }

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    })
  }

  const exportToGoogle = () => {
    if (!schedule || schedule.length === 0) return

    const timeouts: NodeJS.Timeout[] = []

    // Open each task as a separate Google Calendar event
    schedule.forEach((task, index) => {
      // Format times for Google Calendar (YYYYMMDDTHHmmssZ)
      const formatGoogleTime = (date: Date) => {
        const year = date.getFullYear()
        const month = String(date.getMonth() + 1).padStart(2, '0')
        const day = String(date.getDate()).padStart(2, '0')
        const hours = String(date.getHours()).padStart(2, '0')
        const minutes = String(date.getMinutes()).padStart(2, '0')
        const seconds = '00'
        return `${year}${month}${day}T${hours}${minutes}${seconds}`
      }

      const startStr = formatGoogleTime(task.startTime)
      const endStr = formatGoogleTime(task.endTime)

      // Sanitize task name for URL
      const sanitizedName = task.name.replace(/[<>]/g, '')

      const url = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(
        sanitizedName
      )}&dates=${startStr}/${endStr}`

      // Delay each window opening slightly to prevent browser blocking
      const timeout = setTimeout(() => {
        window.open(url, '_blank')
      }, index * 300)

      timeouts.push(timeout)
    })
  }

  const exportToICS = () => {
    if (!schedule) return

    let icsContent = 'BEGIN:VCALENDAR\nVERSION:2.0\nPRODID:-//Wacky Calendar//EN\nCALSCALE:GREGORIAN\n'

    schedule.forEach((task) => {
      // Format dates in local time (not UTC) for better calendar compatibility
      const formatICSDate = (date: Date) => {
        const year = date.getFullYear()
        const month = String(date.getMonth() + 1).padStart(2, '0')
        const day = String(date.getDate()).padStart(2, '0')
        const hours = String(date.getHours()).padStart(2, '0')
        const minutes = String(date.getMinutes()).padStart(2, '0')
        const seconds = '00'
        return `${year}${month}${day}T${hours}${minutes}${seconds}`
      }

      const startStr = formatICSDate(task.startTime)
      const endStr = formatICSDate(task.endTime)

      // Sanitize task name - escape special characters for ICS format
      const sanitizedName = task.name
        .replace(/\\/g, '\\\\')
        .replace(/;/g, '\\;')
        .replace(/,/g, '\\,')
        .replace(/\n/g, '\\n')

      icsContent += 'BEGIN:VEVENT\n'
      icsContent += `DTSTART:${startStr}\n`
      icsContent += `DTEND:${endStr}\n`
      icsContent += `SUMMARY:${sanitizedName}\n`
      if (task.description) {
        const sanitizedDesc = task.description
          .replace(/\\/g, '\\\\')
          .replace(/;/g, '\\;')
          .replace(/,/g, '\\,')
          .replace(/\n/g, '\\n')
        icsContent += `DESCRIPTION:${sanitizedDesc}\n`
      }
      icsContent += `UID:${task.id}@wackycalendar.com\n`
      icsContent += 'END:VEVENT\n'
    })

    icsContent += 'END:VCALENDAR'

    const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = 'wacky-schedule.ics'
    link.click()

    // Clean up
    setTimeout(() => URL.revokeObjectURL(url), 100)
  }

  // Google Calendar Integration
  const googleLogin = useGoogleLogin({
    onSuccess: (tokenResponse) => {
      setGoogleAccessToken(tokenResponse.access_token)
      setTokenExpiry(Date.now() + 3600000) // 1 hour from now
    },
    scope: 'https://www.googleapis.com/auth/calendar.events',
  })

  const handleGoogleSignOut = () => {
    setGoogleAccessToken(null)
    setTokenExpiry(null)
  }

  const handleExportToGoogleCalendar = async () => {
    if (!schedule) return

    // Check token expiry
    if (tokenExpiry && Date.now() > tokenExpiry) {
      alert('🔒 Session expired. Please sign in again.')
      setGoogleAccessToken(null)
      setTokenExpiry(null)
      return
    }

    if (!googleAccessToken) {
      googleLogin()
      return
    }

    // Rate limiting: prevent exports within 3 seconds
    const now = Date.now()
    if (now - lastExportTime < 3000) {
      alert('⏱️ Please wait 3 seconds between exports to prevent duplicates.')
      return
    }
    setLastExportTime(now)

    setIsExportingToGoogle(true)
    try {
      await exportToGoogleCalendar(schedule, googleAccessToken)
      alert('✅ Successfully exported to Google Calendar!')
    } catch (error) {
      console.error('Google Calendar export failed:', error)
      if (error instanceof Error && error.message.includes('401')) {
        alert('🔒 Session expired. Please sign in again.')
        setGoogleAccessToken(null)
        setTokenExpiry(null)
      } else {
        alert('❌ Failed to export to Google Calendar. Please try again.')
      }
    } finally {
      setIsExportingToGoogle(false)
    }
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="mx-auto max-w-4xl space-y-8">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-balance">Wacky Calendar</h1>
          <p className="mt-2 text-muted-foreground text-pretty">
            Make your time interesting with randomized schedules
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Set Your Available Time</CardTitle>
            <CardDescription>
              Example: I have from 1PM-2PM free today. I need to do...
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-4 p-3 rounded-lg bg-muted">
              <label className="text-sm font-medium">Time Window Mode:</label>
              <div className="flex gap-2">
                <Button
                  variant={timeWindowMode === 'single' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => handleModeChange('single')}
                >
                  Single Window
                </Button>
                <Button
                  variant={timeWindowMode === 'multiple' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => handleModeChange('multiple')}
                >
                  Multiple Windows
                </Button>
              </div>
            </div>

            {timeWindowMode === 'single' ? (
              <div className="flex flex-col gap-4">
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => applyTimePreset('morning')}
                    className="flex-1"
                  >
                    <Clock className="mr-2 h-4 w-4" />
                    Morning (8AM-12PM)
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => applyTimePreset('afternoon')}
                    className="flex-1"
                  >
                    <Clock className="mr-2 h-4 w-4" />
                    Afternoon (1PM-5PM)
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => applyTimePreset('evening')}
                    className="flex-1"
                  >
                    <Clock className="mr-2 h-4 w-4" />
                    Evening (6PM-10PM)
                  </Button>
                </div>
                <div>
                  <label className="text-sm font-medium">Start Time</label>
                  <div className="mt-1 flex gap-2">
                    <Select value={startHour} onValueChange={handleStartHourChange}>
                      <SelectTrigger className="flex-1">
                        <SelectValue placeholder="Hour" />
                      </SelectTrigger>
                      <SelectContent>
                        {Array.from({ length: 12 }, (_, i) => i + 1).map((hour) => (
                          <SelectItem key={hour} value={String(hour)}>
                            {hour}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Select value={startMinute} onValueChange={setStartMinute}>
                      <SelectTrigger className="flex-1">
                        <SelectValue placeholder="Minute" />
                      </SelectTrigger>
                      <SelectContent>
                        {['00', '15', '30', '45'].map((minute) => (
                          <SelectItem key={minute} value={minute}>
                            {minute}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Select value={startPeriod} onValueChange={setStartPeriod}>
                      <SelectTrigger className="w-24">
                        <SelectValue placeholder="AM/PM" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="AM">AM</SelectItem>
                        <SelectItem value="PM">PM</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium">End Time</label>
                  <div className="mt-1 flex gap-2">
                    <Select value={endHour} onValueChange={handleEndHourChange}>
                      <SelectTrigger className="flex-1">
                        <SelectValue placeholder="Hour" />
                      </SelectTrigger>
                      <SelectContent>
                        {Array.from({ length: 12 }, (_, i) => i + 1).map((hour) => (
                          <SelectItem key={hour} value={String(hour)}>
                            {hour}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Select value={endMinute} onValueChange={setEndMinute}>
                      <SelectTrigger className="flex-1">
                        <SelectValue placeholder="Minute" />
                      </SelectTrigger>
                      <SelectContent>
                        {['00', '15', '30', '45'].map((minute) => (
                          <SelectItem key={minute} value={minute}>
                            {minute}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Select value={endPeriod} onValueChange={setEndPeriod}>
                      <SelectTrigger className="w-24">
                        <SelectValue placeholder="AM/PM" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="AM">AM</SelectItem>
                        <SelectItem value="PM">PM</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex flex-col gap-4">
                  <div className="flex gap-2 items-end">
                    <div
                      className="flex-1"
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && startHour && startMinute && startPeriod && endHour && endMinute && endPeriod) {
                          addTimeWindow()
                        }
                      }}
                    >
                      <label className="text-sm font-medium">Start Time</label>
                      <div className="mt-1 flex gap-2">
                        <Select value={startHour} onValueChange={handleStartHourChange}>
                          <SelectTrigger className="flex-1">
                            <SelectValue placeholder="Hour" />
                          </SelectTrigger>
                          <SelectContent>
                            {Array.from({ length: 12 }, (_, i) => i + 1).map((hour) => (
                              <SelectItem key={hour} value={String(hour)}>
                                {hour}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Select value={startMinute} onValueChange={setStartMinute}>
                          <SelectTrigger className="flex-1">
                            <SelectValue placeholder="Minute" />
                          </SelectTrigger>
                          <SelectContent>
                            {['00', '15', '30', '45'].map((minute) => (
                              <SelectItem key={minute} value={minute}>
                                {minute}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Select value={startPeriod} onValueChange={setStartPeriod}>
                          <SelectTrigger className="w-24">
                            <SelectValue placeholder="AM/PM" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="AM">AM</SelectItem>
                            <SelectItem value="PM">PM</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="flex-1">
                      <label className="text-sm font-medium">End Time</label>
                      <div className="mt-1 flex gap-2">
                        <Select value={endHour} onValueChange={handleEndHourChange}>
                          <SelectTrigger className="flex-1">
                            <SelectValue placeholder="Hour" />
                          </SelectTrigger>
                          <SelectContent>
                            {Array.from({ length: 12 }, (_, i) => i + 1).map((hour) => (
                              <SelectItem key={hour} value={String(hour)}>
                                {hour}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Select value={endMinute} onValueChange={setEndMinute}>
                          <SelectTrigger className="flex-1">
                            <SelectValue placeholder="Minute" />
                          </SelectTrigger>
                          <SelectContent>
                            {['00', '15', '30', '45'].map((minute) => (
                              <SelectItem key={minute} value={minute}>
                                {minute}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Select value={endPeriod} onValueChange={setEndPeriod}>
                          <SelectTrigger className="w-24">
                            <SelectValue placeholder="AM/PM" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="AM">AM</SelectItem>
                            <SelectItem value="PM">PM</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <Button onClick={addTimeWindow}>
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                {timeWindows.length > 0 && (
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Time Windows:</label>
                    {timeWindows.map((window) => (
                      <div
                        key={window.id}
                        className="flex items-center justify-between rounded-lg border p-3"
                      >
                        <span className="text-sm">
                          {window.startHour}:{window.startMinute} {window.startPeriod} - {window.endHour}:{window.endMinute} {window.endPeriod}
                        </span>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeTimeWindow(window.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Add Your Tasks</CardTitle>
            <CardDescription>
              List what you need to do. Time is automatically estimated but can be adjusted.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex gap-2">
                <Input
                  placeholder="Task name (e.g., Evaluate leads, Go to Gym)"
                  value={newTaskName}
                  onChange={(e) => setNewTaskName(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && !newTaskDescription && addTask()}
                  className="flex-1"
                />
                <Select value={newTaskDuration} onValueChange={setNewTaskDuration}>
                  <SelectTrigger className="w-32">
                    <SelectValue placeholder="Duration" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="15">15 min</SelectItem>
                    <SelectItem value="30">30 min</SelectItem>
                    <SelectItem value="45">45 min</SelectItem>
                    <SelectItem value="60">1 hour</SelectItem>
                    <SelectItem value="90">1.5 hours</SelectItem>
                    <SelectItem value="120">2 hours</SelectItem>
                  </SelectContent>
                </Select>
                <Button onClick={addTask}>
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              <Textarea
                placeholder="Optional: Add notes or details about this task"
                value={newTaskDescription}
                onChange={(e) => setNewTaskDescription(e.target.value)}
                className="resize-none"
                rows={2}
              />
            </div>

            {tasks.length > 0 && (
              <>
                <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
                  <div className="flex items-center gap-2 text-sm font-medium">
                    <span>{tasks.length} {tasks.length === 1 ? 'task' : 'tasks'}</span>
                    <span>•</span>
                    <span>{tasks.reduce((sum, task) => sum + task.duration, 0)} min total</span>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={clearAllData}
                  >
                    <Trash2 className="mr-2 h-4 w-4" />
                    Clear All
                  </Button>
                </div>
                <div className="space-y-2">
                  {tasks.map((task) => (
                    <div
                      key={task.id}
                      className="rounded-lg border p-3"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <span className="font-medium">{task.name}</span>
                          <span className="text-sm text-muted-foreground">
                            {task.duration} min
                          </span>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeTask(task.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                      {task.description && (
                        <p className="text-sm text-muted-foreground mt-2">{task.description}</p>
                      )}
                    </div>
                  ))}
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {tasks.length > 0 &&
          ((timeWindowMode === 'single' && startHour && startMinute && startPeriod && endHour && endMinute && endPeriod) ||
            (timeWindowMode === 'multiple' && timeWindows.length > 0)) && (
            <div className="space-y-2">
              {!timeValidation.isValid && (
                <div className="rounded-lg bg-destructive/10 border border-destructive/20 p-4 text-sm">
                  <p className="font-semibold text-destructive">Too many tasks for the available time</p>
                  <p className="text-muted-foreground mt-1">
                    You have {timeValidation.totalTaskMinutes} minutes of tasks but only {timeValidation.availableMinutes} minutes available. Please remove some tasks or extend your time window{timeWindowMode === 'multiple' ? 's' : ''}.
                  </p>
                </div>
              )}
              <Button
                onClick={generateSchedule}
                size="lg"
                className="w-full"
                disabled={!timeValidation.isValid}
              >
                <Calendar className="mr-2 h-5 w-5" />
                Make My Time Interesting
              </Button>
            </div>
          )}

        {schedule && schedule.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Your Wacky Schedule</CardTitle>
              <CardDescription>
                Tasks arranged in a fun, random order (outdoor tasks grouped together)
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                {schedule.map((task, index) => (
                  <div
                    key={task.id}
                    className="flex items-center gap-4 rounded-lg border p-4"
                  >
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-primary-foreground font-semibold">
                      {index + 1}
                    </div>
                    <div className="flex-1">
                      <div className="font-semibold">{task.name}</div>
                      <div className="text-sm text-muted-foreground">
                        {formatTime(task.startTime)} - {formatTime(task.endTime)}{' '}
                        ({task.duration} min)
                      </div>
                      {task.description && (
                        <p className="text-sm text-muted-foreground mt-1">{task.description}</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex gap-2 pt-4 border-t">
                <Button onClick={regenerateSchedule} variant="outline" className="flex-1 bg-transparent">
                  <RotateCcw className="mr-2 h-4 w-4" />
                  Randomize Again
                </Button>
                <Button onClick={copyScheduleToClipboard} variant="outline" className="flex-1 bg-transparent">
                  <Copy className="mr-2 h-4 w-4" />
                  Copy as Text
                </Button>
              </div>

              <div className="space-y-2">
                <Button onClick={exportToICS} className="w-full">
                  <Download className="mr-2 h-4 w-4" />
                  Download Calendar File (.ics)
                </Button>
                <p className="text-xs text-center text-muted-foreground">
                  Works with Google Calendar, Apple Calendar, Outlook, and more
                </p>

                {/* Google Calendar Export with OAuth */}
                <div className="flex items-center gap-2">
                  <Button
                    onClick={handleExportToGoogleCalendar}
                    variant="outline"
                    className="flex-1 bg-transparent"
                    size="sm"
                    disabled={isExportingToGoogle}
                  >
                    <Calendar className="mr-2 h-4 w-4" />
                    {isExportingToGoogle ? 'Exporting...' : googleAccessToken ? 'Export to Google Calendar' : 'Sign in & Export to Google'}
                  </Button>
                  {googleAccessToken && (
                    <Button
                      onClick={handleGoogleSignOut}
                      variant="outline"
                      size="sm"
                    >
                      Sign Out
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
